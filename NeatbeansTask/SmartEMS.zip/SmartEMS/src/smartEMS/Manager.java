package smartEMS;
public class Manager extends Employee {
    private int teamSize;

    public Manager(int teamSize, double salary, String department, String name, int id) {
        super(salary, department, name, id);
        this.teamSize = teamSize;
    }
    
    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.println("Team Size: " + teamSize);
    }
}

class Developer extends Employee{
    private String technology;

    public Developer(String technology, double salary, String department, String name, int id) {
        super(salary, department, name, id);
        this.technology = technology;
    }
    
    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.println("Technology: " + technology);
    }
}