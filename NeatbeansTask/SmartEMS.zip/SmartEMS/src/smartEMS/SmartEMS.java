package smartEMS;
public class SmartEMS {
    public static void main(String[] args) {
        
        Manager m1 = new Manager(5,100000,"HR","Harshad", 1);
        Developer d1 = new Developer("Java",50000,"cloud","shantanu",102);
        
        System.out.println("Manager Details : ");
        m1.displayInfo();
        System.out.println();
        System.out.println("Developer details : ");
        d1.displayInfo();
        
    }    
}
