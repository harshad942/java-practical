package sudoku;
public class Sudoku {
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
