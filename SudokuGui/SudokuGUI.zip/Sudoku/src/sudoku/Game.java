package sudoku;
import java.util.Random;
import java.util.Scanner;

public class Game {
    public static void generateSudoku(String[][] layout, int size) {
        for (int i = 0;i<size; i++) {
            for (int j =0;j<size;j++) {
                layout[i][j] = Integer.toString((i+j)%size+1);
            }
        }
    }
    public static void removerandom(String layout[][] , int size){
        Random random = new Random();
        int totalcell = size*size;
        int removecell = (int)(totalcell*0.5);

        int remove = 0;
        while(remove < removecell){
            int i = random.nextInt(size);
            int j = random.nextInt(size);
            if(!layout[i][j].equals("?")){
                layout[i][j] = "?";
                remove++;
            }
        }
    }
    public static void play(String layout[][]){
        Scanner sc = new Scanner(System.in);
        for(int i=0;i<layout.length;i++){
            for(int j=0;j<layout[0].length;j++){
                if(layout[i][j].equals("?")){
                    System.out.print("Enter number at row : "+(i+1)+", col : "+(j+1)+" = ");
                    String num = sc.next();
                    layout[i][j] = num;
                    printSudoku(layout);
                }
            }
        }
    }

    public static boolean checkans(String[][] layout, int size) {
        for (int i = 0;i<size;i++) {
            for (int j = 0;j<size;j++) {
                String value = layout[i][j];
    
                // Check row
                for (int k =0;k<size;k++) {
                    if (k != j && value.equals(layout[i][k])) {
                        return false;
                    }
                }
    
                // Check column
                for (int k = 0;k<size;k++) {
                    if (k != i && value.equals(layout[k][j])) {
                        return false;
                    }
                }
            }
        }
        return true;
    }
    
    public static void printSudoku(String[][] layout) {
        for (int i =0;i<layout.length; i++) {
            for (int j =0;j<layout[0].length; j++) {
                System.out.print(layout[i][j]+" ");
            }
            System.out.println();
        }
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("enter size : ");
        int size = sc.nextInt();
        String[][] layout = new String[size][size];
        generateSudoku(layout, size);
        removerandom(layout, size);
        printSudoku(layout);
        play(layout);
        boolean result = checkans(layout, size);
        if(result == true){
            System.out.print("congratulation you won...");
        }else{
            System.out.print("well played, Try again...");
        }

    }
}
